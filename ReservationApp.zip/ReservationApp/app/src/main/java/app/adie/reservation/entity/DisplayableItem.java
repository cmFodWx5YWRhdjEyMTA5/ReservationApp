package app.adie.reservation.entity;

public interface DisplayableItem {
}
