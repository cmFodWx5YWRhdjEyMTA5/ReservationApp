package app.adie.reservation.entity;

public class KursiDetil {
    public int col;
    public String no;
    public int row;
    public String type;
}
